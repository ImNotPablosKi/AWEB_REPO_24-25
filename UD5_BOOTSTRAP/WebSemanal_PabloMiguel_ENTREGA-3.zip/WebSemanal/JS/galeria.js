function imagen(ruta) {
    document.getElementById('img-BIG').src = ruta;
    
}